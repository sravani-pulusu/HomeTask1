package com.ht2.Hometask2;

public class Milkchocolate extends Sweets {
    public int calcwt(int quantity,int weight)
    {   
        return weight*quantity;
     
    }


}
