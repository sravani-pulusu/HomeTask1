package com.ht2.Hometask2;
public class Whitechocolate extends Sweets {
    public int calcwt(int quantity,int weight)
    {   
        return weight*quantity;
     
    }


}